package com.example.myapplication;

public class Statistics {

    public String[] _identifiers;

    public Statistics(){


    }
}
