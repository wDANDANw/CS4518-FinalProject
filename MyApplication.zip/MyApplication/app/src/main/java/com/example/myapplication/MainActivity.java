package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private EditText computation_level;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        computation_level = findViewById(R.id.computation_level_edit_text);
        mDatabase = FirebaseDatabase.getInstance().getReference().child("FINAL_PROJECT").child("Emulator Statistics");
    }

    private class ConnectionTask extends AsyncTask{
        private String _error_str = "NO ERRORS!";
        private String[] _client_identifiers = new String[2];
        private String _ip_addr = null;
        private String _host_name = null;
        private InetAddress inetAddress = null;
        private int _task_id = -1;

        public ConnectionTask(int task_id){
            _task_id = task_id;
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                inetAddress  = InetAddress. getLocalHost();
            } catch (UnknownHostException e) {
                _error_str = "Error in do in background - line 28";
                e.printStackTrace();
            }

            if (inetAddress != null) {
                _ip_addr = inetAddress.getHostAddress();
                _host_name = inetAddress.getHostName();
            }

            _client_identifiers[0] = _ip_addr;
            _client_identifiers[1] = _host_name;
            _client_identifiers[2] = Integer.toString(_task_id);

            ClientSocketModule client = new ClientSocketModule(_client_identifiers);

            client.firstSocket();

            String processString = client.secondSocket();
            UnitComputationSHA256 unitComputation = new UnitComputationSHA256(processString);
            String output = unitComputation.doUnitComputation();

            client.ThirdSocket(output);

            return null;
        }
    }
    public void doSth(View view) {
        int repeat_times = Integer.parseInt(computation_level.toString());

        if (repeat_times < 0 || repeat_times > 3){
            repeat_times = 1;
        }

        for (int i = 0; i < repeat_times; i++) {
            new ConnectionTask(i).execute();
        }
    }
}
