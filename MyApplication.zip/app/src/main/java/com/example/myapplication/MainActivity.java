package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private class Connection extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] objects) {
            String[] args = {"1"};
            ClientSocketModule client = new ClientSocketModule(args);
            client.firstSocket();

            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }

            client.secondSocket();

            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }

            String output = "123";

            client.ThirdSocket(output);
            return null;
        }
    }
    public void doSth(View view) {
        new Connection().execute();
    }
}
